package com.hito;

import java.io.Serializable;

public class Serie implements Serializable {
    private int id;
    private String nombre_series;
    private int year;
    private float puntuacion;


    //CONTRUCTOR
    public Serie(int id, String nombre_series, int year, float puntuacion) {
        this.id = id;
        this.nombre_series = nombre_series;
        this.year = year;
        this.puntuacion = puntuacion;
    }


    //GETTERS
    public int getId() {
        return id;
    }

    public String getNombre_series() {
        return nombre_series;
    }

    public int getYear() {
        return year;
    }

    public float getPuntuacion() {
        return puntuacion;
    }


    //SETTERS
    public void setId(int id) {
        this.id = id;
    }

    public void setNombre_series(String nombre_series) {
        this.nombre_series = nombre_series;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public void setPuntuacion(float puntuacion) {
        this.puntuacion = puntuacion;
    }
}//CIERRA CLASS
