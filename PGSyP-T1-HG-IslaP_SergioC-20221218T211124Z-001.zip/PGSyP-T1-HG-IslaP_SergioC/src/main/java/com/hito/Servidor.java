package com.hito;

import java.io.*;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.*;

public class Servidor {
    static Map<Integer, Serie> seriesMap;

    public static void main(String[] args) {
        File fichero = new File("series.csv");
        seriesMap = new HashMap<Integer, Serie>();
        Scanner sc;
        try {
            sc = new Scanner(fichero);
            while (sc.hasNextLine()) {
                    String linea = sc.nextLine();
                    fragmentarLinea(linea);
            }
            sc.close();
        } catch (FileNotFoundException e) {
            System.out.println("No se ha podido leer el archivo");
            System.out.println(e.getMessage());
        }


        try {
            //CREAMOS LA CONEXION POR RED ENTRE CLIENTE/SERVIDOR
            //Socket del extremo del servidor
            ServerSocket servidor = new ServerSocket();
            //Definimos la direccion IP y puerto del servidor.
            InetSocketAddress direccion = new InetSocketAddress("192.168.1.101", 2000);
            //Asignamos al socket del servidor la direccion IP y puerto mediante el metodo '.bind()'
            servidor.bind(direccion);
            System.out.println("Servidor creado");
            //Comprobamos la direccion.
            System.out.println("Dirección IP: " + direccion.getAddress());
            Scanner sc2 = new Scanner(System.in);

            while (true) {
                System.out.println("Servidor esperando solicitud");
                Socket conexionCliente = servidor.accept();
                System.out.println("Cliente conectado");
                new HiloEscuchador(conexionCliente, seriesMap);
            }
        } catch (IOException e) {
            System.out.println("No se pudo realizar la conexión entre cliente y servidor");
            throw new RuntimeException(e);
        }//CIERRA TRY CATCH
    }//CIERRA MAIN


    //METODOS
    public static void fragmentarLinea(String linea) {
        Scanner sc = new Scanner(linea);
        sc.useDelimiter(",");
        Integer id = Integer.parseInt(sc.next());
        String nombre_series = sc.next();
        int year = Integer.parseInt(sc.next());
        float puntuacion = Float.parseFloat(sc.next());
        Serie s = new Serie(id,nombre_series,year,puntuacion);
        seriesMap.put(id,s);
    }
}//CIERRA CLASS

