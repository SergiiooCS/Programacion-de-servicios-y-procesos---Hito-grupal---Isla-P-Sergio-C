package com.hito;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Map;

public class HiloEscuchador implements Runnable{
    private Thread hilo;
    private static int numCliente = 0;
    private Map<Integer, Serie> seriesMap;
    private Socket conexionCliente;
    private ObjectInputStream entrada;
    private ObjectOutputStream salida;


    //CONSTRUCTOR
    public HiloEscuchador(Socket cliente, Map<Integer, Serie> seriesMap) {
        numCliente++;
        hilo = new Thread(this, "Cliente" + numCliente);
        this.conexionCliente = cliente;
        this.seriesMap = seriesMap;
        hilo.start();
    }



    //METODOS
    public void run() {
        System.out.println("Estableciendo comunicaci�n con " + hilo.getName());
        try {
            salida = new ObjectOutputStream(conexionCliente.getOutputStream());
            entrada = new ObjectInputStream(conexionCliente.getInputStream());
            String id;
            do {
                id = (String) entrada.readObject();
                if (id.trim().equals("FIN")) {
                    salida.writeObject("Hasta pronto, gracias por establecer conexi�n");
                    System.out.println(hilo.getName() + " ha cerrado la comunicaci�n");
                } else {
                    System.out.println(hilo.getName() + " consulta la serie: " + id);
                    // Enviamos el objeto correspondiente al alumno consultado.
                    try{
                        Integer idInt = Integer.parseInt(id);
                        Serie mensaje = seriesMap.get(idInt);
                        if (mensaje==null) {
                            salida.writeObject("Serie no encontrado");
                        }
                        else {
                            salida.writeObject(mensaje);
                        }
                    }catch(IOException e){
                        e.printStackTrace();
                        System.out.println("fin - Debe ser en mayusculas");
                    }
                }
            } while ((!id.trim().equals("FIN")));
            entrada.close();
            salida.close();
            conexionCliente.close();
        } catch (IOException | ClassNotFoundException e) {
            System.out.println(e.getMessage());
        }
    }

}//CIERRA CLASS
