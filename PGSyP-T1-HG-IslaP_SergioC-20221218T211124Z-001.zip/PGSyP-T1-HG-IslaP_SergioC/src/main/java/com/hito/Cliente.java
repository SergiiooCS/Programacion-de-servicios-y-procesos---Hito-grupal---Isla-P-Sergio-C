package com.hito;

import java.io.*;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Cliente {

    private static ObjectInputStream entrada;
    private static ObjectOutputStream salida;

    public static void main(String[] args) {
        System.out.println(" APLICACIÓN CLIENTE");
        System.out.println("-----------------------------------");
        Scanner lector = new Scanner(System.in);
        try {
            Socket cliente = new Socket();
            InetSocketAddress direccionServidor = new InetSocketAddress("192.168.1.101", 2000);
            System.out.println("Esperando a que el servidor acepte la conexión");
            cliente.connect(direccionServidor);
            // Conectamos con el servidor.
            System.out.println("Comunicación establecida con el servidor");

            salida = new ObjectOutputStream(cliente.getOutputStream());
            entrada = new ObjectInputStream(cliente.getInputStream());

            String opc = "";
            while (!opc.equals("FIN")) {
                System.out.println("ID de serie (FIN para terminar): ");
                opc = lector.nextLine();
                // Envio consulta al servidor.
                salida.writeObject(opc);
                // Recibo respuesta del servidor.
                Object mensaje = entrada.readObject();
                if (mensaje instanceof String) {
                    System.out.println(mensaje);
                    if (mensaje.equals("FIN")) break;
                }
                else {
                    Serie serie = (Serie) mensaje;
                    System.out.println("ID de la serie : " + serie.getId());
                    System.out.println("Nombre de la serie: " + serie.getNombre_series());
                    System.out.println("Año de la serie : " + serie.getYear());
                    System.out.println("Puntuacion de la serie : " + serie.getPuntuacion());
                }
            }
            entrada.close();
            salida.close();
            cliente.close();
            System.out.println("Comunicación cerrada");
        } catch (UnknownHostException e) {
            System.out.println("No se puede establecer comunicación con el servidor");
            System.out.println(e.getMessage());
        } catch (IOException e) {
            System.out.println("Error de E/S");
            System.out.println(e.getMessage());
        } catch (ClassNotFoundException e) {
            System.out.println(e.getMessage());
        }
        lector.close();
    }//CIERRA MAIN
}//CIERRA CLASS

